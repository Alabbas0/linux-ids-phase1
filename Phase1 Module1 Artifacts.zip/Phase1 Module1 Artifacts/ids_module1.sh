#!/bin/bash

# Define the log file to save the script's output
REPORT_FILE="ids_alerts.log"

# 1. Input Checking
# Ensure the script is run as root, which is required to read security logs
if [ "$EUID" -ne 0 ]; then
  echo "[-] Error: Please run this script with sudo."
  exit 1
fi

# Check if the user passed a specific log file as an argument
if [ $# -eq 1 ]; then
    LOG_SOURCE="$1"
    if [ ! -f "$LOG_SOURCE" ]; then
        echo "[-] Error: The file $LOG_SOURCE does not exist."
        exit 1
    fi
    echo "[+] Reading from provided log file: $LOG_SOURCE" | tee $REPORT_FILE
    READ_CMD="cat $LOG_SOURCE"
else
    # Default to systemd journal if no file is provided
    echo "[+] No file provided. Defaulting to system journal (journalctl)." | tee $REPORT_FILE
    READ_CMD="journalctl -q"
fi

echo "==================================================" | tee -a $REPORT_FILE
echo "[*] Analyzing logs for intrusion patterns..." | tee -a $REPORT_FILE

# 2. Detect failed logins using regular expressions
echo "--------------------------------------------------" | tee -a $REPORT_FILE
echo "[*] Checking for Failed SSH Logins:" | tee -a $REPORT_FILE

# Execute the read command and filter with regex
eval $READ_CMD | grep -E "Failed password|authentication failure.*sshd" > temp_ssh.txt

if [ -s temp_ssh.txt ]; then
    echo "[!] ALERT: Failed logins detected!" | tee -a $REPORT_FILE
    # Show only the last 5 attempts to keep the output clear
    tail -n 5 temp_ssh.txt | tee -a $REPORT_FILE
else
    echo "[+] No failed logins found." | tee -a $REPORT_FILE
fi

# 3. Detect failed sudo attempts using regular expressions
echo "--------------------------------------------------" | tee -a $REPORT_FILE
echo "[*] Checking for Failed Sudo Attempts:" | tee -a $REPORT_FILE

eval $READ_CMD | grep -E "sudo:.*(authentication failure|incorrect password)" > temp_sudo.txt

if [ -s temp_sudo.txt ]; then
    echo "[!] ALERT: Failed sudo attempts detected!" | tee -a $REPORT_FILE
    tail -n 5 temp_sudo.txt | tee -a $REPORT_FILE
else
    echo "[+] No failed sudo attempts found." | tee -a $REPORT_FILE
fi

echo "==================================================" | tee -a $REPORT_FILE
echo "[+] Analysis complete. Results have been saved to $REPORT_FILE"

# Cleanup temporary files
rm -f temp_ssh.txt temp_sudo.txt
